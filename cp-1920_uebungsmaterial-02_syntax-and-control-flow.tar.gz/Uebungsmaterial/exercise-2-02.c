#include <stdio.h>

void fib_while()
{
    //TODO
}

void fib_do_while()
{
    //TODO
}

void fib_for()
{
    //TODO
}

int main()
{
    fib_while();
    fib_do_while();
    fib_for();

    return 0;
}
