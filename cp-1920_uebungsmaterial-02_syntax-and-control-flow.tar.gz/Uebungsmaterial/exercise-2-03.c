#include <stdio.h>      /* printf */
#include <stdlib.h>     /* atoi */

int main(int argc, char *argv[])
{
  int val = (argc > 1) ? atoi(argv[1]) : 0;

  // Erweitern Sie fuer die Zahlen 0-9, Bsp. für 0
  if (val == 0)
  {
      printf("null");
  }
}
